from interface import *

player_interface = PlayerInterface()